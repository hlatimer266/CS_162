/**************************************************************
* * Author: Harrison Latimer
* * Date: 11/18/2017
* Description: Main for Assignment 4
**************************************************************/

#include<iostream>
#include"Character.h"
#include"Barbarian.h"
#include"Vampire.h"
#include"Menu.h"

int main()
{
	Menu m1; 
	m1.game();
	return 0;
}
