/*********************************************************************
** Class Name: checkNum
** Date: 10/30/17
** Description: Header file for the checkNum functions. 
*********************************************************************/

#ifndef CHECKINT_HPP
#define CHECKINT_HPP

#include <string>

bool checkInt(std::string strValue);
bool checkStr(std::string, bool);


#endif