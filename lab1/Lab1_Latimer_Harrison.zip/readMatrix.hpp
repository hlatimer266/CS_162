/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 9/25/2017
 * Description: Header file for readMatrix() function 
 **************************************************************/
#ifndef READMATRIX_HPP
#define READMATRIX_HPP 
#include <iostream>

using namespace std;

void readMatrix(int **matPtr, int size);

#endif
