/**************************************************************
 * * Author: Harrison Latimer
 * * Date: 9/25/2017
 * Description: Header file for determinant() function 
 **************************************************************/
#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP 
#include <iostream>

using namespace std; 

int determinant(int **matPtr, int size);

#endif
