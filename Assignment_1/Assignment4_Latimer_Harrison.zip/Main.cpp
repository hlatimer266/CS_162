#include<iostream>
#include"Character.h"
#include"Barbarian.h"
#include"Vampire.h"
#include"Menu.h"

int main()
{
	Menu m1; 
	m1.game();
	return 0;
}
